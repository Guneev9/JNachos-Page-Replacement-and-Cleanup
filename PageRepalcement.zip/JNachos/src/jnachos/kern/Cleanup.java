package jnachos.kern;

import jnachos.machine.TranslationEntry;

import java.util.ArrayList;
import java.util.HashMap;

public class Cleanup
{
	//counter
	public static int count= 0;
	
	//list of pages stored
	public static ArrayList<NachosProcess> cleanup_processes = new ArrayList<>();
	
	public static HashMap<Integer, ArrayList<Integer>> clean_map = new HashMap<>();
	
	//this is an array list of page tables
	//it will do swapping file cleanup process when the process finishes or exits
	public static ArrayList<TranslationEntry[]> process_Pagetablelist = new ArrayList<>();
}

