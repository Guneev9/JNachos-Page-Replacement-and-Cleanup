/**
 * Copyright (c) 1992-1993 The Regents of the University of California.
 * All rights reserved.  See copyright.h for copyright notice and limitation 
 * of liability and disclaimer of warranty provisions.
 *
 *  Created by Patrick McSweeney on 12/13/08.
 *
 */
package jnachos.kern;
//for project2 changes
import java.util.Arrays;

import jnachos.machine.*;

/**
 * The ExceptionHanlder class handles all exceptions raised by the simulated
 * machine. This class is abstract and should not be instantiated.
 */
public abstract class ExceptionHandler
{

	/**
	 * This class does all of the work for handling exceptions raised by the
	 * simulated machine. This is the only funciton in this class.
	 *
	 * @param pException
	 *            The type of exception that was raised.
	 * @see ExceptionType.java
	 */
	public static void handleException(ExceptionType pException) 
	{
		switch (pException) 
		{
		// If this type was a system call
		case SyscallException:

			// Get what type of system call was made
			int type = Machine.readRegister(2);

			// Invoke the System call handler
			SystemCallHandler.handleSystemCall(type);
			break;
			
	//project2 changes- new switch case addition 
			//new case for exception handling when page fault  occurs 
			//means when the desired page is not there in memory
			
	//When the process references an invalid page, the machine will raise a page fault exception 
		//(if a page is marked valid, no fault is generated)
		case PageFaultException: 
			
			//getting the address space for the current process
			int physical_pageno = JNachos.getCurrentProcess().getSpace().mFreeMap.find();
			
			//The failing virtual address on an exception(when page fault occurs)
			//The virtual address that caused the page fault will be in register 39 (BadVAddrReg). 
			int bad_virtual_Addr = Machine.readRegister(Machine.BadVAddrReg);
			
			//getting the address space for current process
			AddrSpace addrspace_currect = JNachos.getCurrentProcess().getSpace();
			
			//array of size equal to pagesize
			byte[] bytes= new byte[Machine.PageSize];
			
			//Reading this register and calculate the virtual page number (vpn).
			int vpn=(int)(bad_virtual_Addr/Machine.PageSize);
		
			
			//Select a physical page in which to load the virtual page. If no free physical page is available, 
			//a "victim" virtual page must be selected to swap out and the physical page it was occupying can then be selected
			TranslationEntry poor_Transl_Entry = addrspace_currect.mPageTable[vpn];

	
			//The simplest page replacement algorithms is a FIFO algorithm, where it
			//associates with each page the time when that page was brought into memory. 
			//When page must be replaced, the oldest page is chosen. We create a FIFO queue which hold all pages in memory. 
			//We replace the page at the head of queue. when a page is brought into memory, we insert it at the tail of the queue.
			JNachos.processvirtspace_file.readAt(bytes, Machine.PageSize, poor_Transl_Entry.curr_virt_pgno* Machine.PageSize);
			
			//pagefault 
			System.out.println("PageFault ocurred for this Address "+ bad_virtual_Addr);

			/* Allocate a free page, returning its physical page number or -1
				if there are no free pages available. */
			if (physical_pageno == -1)
			{ 
				//remove front page from list
				TranslationEntry delete_page = JNachos.FIFO_List.removeFirst();
				
				//if dirty bit is true
				//bit is set by the hardware every time the page is modified.
				if (delete_page.dirty)
				{
					byte[] victim_pg_evict = new byte[Machine.PageSize];
					
					//Copy an array from the specified source array, beginning at the specified position, 
					//to the specified position of the destination array
					System.arraycopy(Machine.mMainMemory, delete_page.physicalPage *Machine.PageSize, victim_pg_evict, 0, Machine.PageSize );
		
					//writing to file
					JNachos.processvirtspace_file.writeAt(victim_pg_evict, Machine.PageSize, delete_page.curr_virt_pgno*Machine.PageSize);
					
				}
				
				//updating bits
				poor_Transl_Entry.physicalPage = delete_page.physicalPage;
				poor_Transl_Entry.valid = true;
				poor_Transl_Entry.use = true;
				delete_page.dirty = false;
				delete_page.use = false;
				delete_page.valid = false;
				delete_page.physicalPage =-1; //FIFO
				
			}
			//when physical page number is not -1
			else 
			{
				poor_Transl_Entry.physicalPage = physical_pageno;
				poor_Transl_Entry.valid = true;
				poor_Transl_Entry.use = true;
			}
			
			//Assigns particular byte value to each element of the specified range of the specified array of bytes.
			Arrays.fill(Machine.mMainMemory, poor_Transl_Entry.physicalPage * Machine.PageSize, (poor_Transl_Entry.physicalPage + 1) * Machine.PageSize, (byte) 0);
			
			//Copy an array from the particular source array, beginning at the specified position, to the specified position of the destination array
			System.arraycopy(bytes, 0, Machine.mMainMemory, poor_Transl_Entry.physicalPage * Machine.PageSize, Machine.PageSize);
			
			//adding to the end of list
			JNachos.FIFO_List.addLast(poor_Transl_Entry);
			break;	
			
			
		// All other exceptions shut down for now
		default:
			System.exit(0);
		}
	}
}
